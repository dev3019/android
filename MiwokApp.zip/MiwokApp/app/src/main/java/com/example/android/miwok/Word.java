package com.example.android.miwok;

/**
 * Created by Divyansh T on 04-01-2017.
 */

public class Word {

    //String for default words
    private String mDefaultTranslation;
    //String for miwok words
    private String mMiwokTranslation;
    //integer for image resource id
    private int mImageResoucreId = NO_IMAGE_RESOURCE;
    private static final int NO_IMAGE_RESOURCE = -1;
    //integer for audio files
    private int mAudioFile;

    //constructor without images
    public Word(String defaultTranslation, String miwokTranslation, int audioFile) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mAudioFile = audioFile;
    }

    //constructor with images
    public Word(String defaultTranslation, String miwokTranslation, int imageResoucreId, int audioFile) {
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResoucreId = imageResoucreId;
        mAudioFile = audioFile;
    }

    //To get default word
    public String getDefaultWord() {
        return mDefaultTranslation;
    }

    //To get miwok word
    public String getMiwokWord() {
        return mMiwokTranslation;
    }

    //to get image
    public int getImageResoucreId() {
        return mImageResoucreId;
    }

    //to check for image
    public boolean hasImage() {
        return mImageResoucreId != NO_IMAGE_RESOURCE;
    }

    //to get audio file
    public int getAudioFile() {
        return mAudioFile;
    }

}
