package com.example.divyansh.myhabittracker;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.divyansh.myhabittracker.data.HabitDbHelper;

/**
 * Created by Divyansh on 28/05/2017.
 */

public class MainActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        HabitDbHelper habitDbHelper=new HabitDbHelper(this);
        habitDbHelper.insertHabits("Raj","Male","Yes",2);
        Cursor cursor = habitDbHelper.getData();
        TextView displayView = (TextView) findViewById(R.id.text);
        displayView.setText("The habits table contains " + cursor.getCount() + " users.\n\n");
    }
}
