package com.example.divyansh.myhabittracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

import com.example.divyansh.myhabittracker.R;
import com.example.divyansh.myhabittracker.data.HabitContract.HabitEntry;

/**
 * Created by Divyansh on 27/05/2017.
 */

public class HabitDbHelper extends SQLiteOpenHelper {
    public static final String LOG_TAG = HabitDbHelper.class.getSimpleName();
    private static final String DATABASE_NAME = "habits.db";
    private static final int DATABASE_VERSION = 1;

    public HabitDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_HABITS_TABLE =  "CREATE TABLE " + HabitEntry.TABLE_NAME + " ("
                + HabitEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + HabitEntry.COLUMN_NAME+ " TEXT NOT NULL, "
                + HabitEntry.COLUMN_GENDER+ " TEXT, "
                + HabitEntry.COLUMN_HABIT_JOG+ " TEXT, "
                + HabitEntry.COLUMN_HABIT_WORKOUT + " INTEGER NOT NULL DEFAULT 0);";
        db.execSQL(SQL_CREATE_HABITS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+HabitEntry.TABLE_NAME);
        onCreate(db);
    }
    //to insert data
    public void insertHabits(String name,String gender,String jog,int workout){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(HabitEntry.COLUMN_NAME,name);
        values.put(HabitEntry.COLUMN_GENDER,gender);
        values.put(HabitEntry.COLUMN_HABIT_JOG,jog);
        values.put(HabitEntry.COLUMN_HABIT_WORKOUT,workout);
        db.insert(HabitEntry.TABLE_NAME,null,values);
        db.close();
    }
    //to read the data
    public Cursor getData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection={
                HabitEntry._ID,
                HabitEntry.COLUMN_NAME,
                HabitEntry.COLUMN_GENDER,
                HabitEntry.COLUMN_HABIT_JOG,
                HabitEntry.COLUMN_HABIT_WORKOUT};
        Cursor result = db.query(HabitEntry.TABLE_NAME,projection,null,null,null,null,null);
        return result;
    }
}
