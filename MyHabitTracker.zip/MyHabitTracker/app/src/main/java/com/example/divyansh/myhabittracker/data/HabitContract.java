package com.example.divyansh.myhabittracker.data;

import android.provider.BaseColumns;

/**
 * Created by Divyansh on 27/05/2017.
 */

public final class HabitContract {

    private HabitContract() {
    }

    public static final class HabitEntry implements BaseColumns {

        public final static String TABLE_NAME = "habit";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_NAME = "name";
        public final static String COLUMN_GENDER = "gender";
        public final static String COLUMN_HABIT_JOG = "jog";
        public final static String COLUMN_HABIT_WORKOUT = "workout";

        public final static int GENDER_UNKNOWN = 0;
        public final static int GENDER_MALE = 1;
        public final static int GENDER_FEMALE = 2;
    }
}
