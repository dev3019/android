package com.example.divyansh.inventoryapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.divyansh.inventoryapp.data.Contract.Entry;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * Created by Divyansh on 04/06/2017.
 */

public class AddActivity extends AppCompatActivity {
    static final int REQUEST_CAMERA=1;
    byte[]imageBlob=null;
    private ImageView imageView;
    private EditText nameTextView;
    private EditText quantityTextView;
    private EditText priceTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Button imageButton=(Button)findViewById(R.id.add_image_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (intent.resolveActivity(getPackageManager())!=null)
                    startActivityForResult(intent,REQUEST_CAMERA);
            }
        });
        nameTextView=(EditText)findViewById(R.id.add_item_name);
        quantityTextView=(EditText)findViewById(R.id.add_item_quantity);
        priceTextView=(EditText)findViewById(R.id.add_item_price);
        imageView=(ImageView)findViewById(R.id.add_item_image);

        Button saveButton=(Button)findViewById(R.id.add_data_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
    }

    private void insertData() {
        String name=nameTextView.getText().toString().trim();
        String mQuantity=quantityTextView.getText().toString().trim();
        String mPrice=priceTextView.getText().toString().trim();
        int quantity=-1;
        if (!mQuantity.isEmpty()){
            quantity=Integer.parseInt(mQuantity);
        }
        float price=-1;
        if (!mPrice.isEmpty()){
            price=Float.parseFloat(mPrice);
            price=Utilities.formatFloat(price);
        }

        ContentValues values=new ContentValues();
        values.put(Entry.COLUMN_NAME,name);
        values.put(Entry.COLUMN_QUANTITY,quantity);
        values.put(Entry.COLUMN_PRICE,price);
        values.put(Entry.COLUMN_IMAGE,imageBlob);

        Uri uri=getContentResolver().insert(Entry.CONTENT_URI,values);

        if (ContentUris.parseId(uri)!=-1){
            Toast.makeText(getApplicationContext(),R.string.data_saved,Toast.LENGTH_SHORT).show();
            NavUtils.navigateUpFromSameTask(this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode==REQUEST_CAMERA){
            if (resultCode==RESULT_OK){
                Bitmap image=(Bitmap)data.getExtras().get("data");
                imageView.setImageBitmap(image);

                ByteArrayOutputStream stream= new ByteArrayOutputStream();
                image.compress(Bitmap.CompressFormat.PNG,100,stream);
                imageBlob=stream.toByteArray();
            }
        }
    }
}
