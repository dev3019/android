package com.example.divyansh.inventoryapp.data;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by Divyansh on 04/06/2017.
 */

public final class Contract {

    public static String CONTENT_AUTHOORITY = "com.example.divyansh.inventoryapp";
    private static Uri CONTENT_BASE_URI = Uri.parse("content://" + CONTENT_AUTHOORITY);

    private Contract() {
    }

    public static final class Entry implements BaseColumns {
        public static String TABLE_NAME = "inventory";
        public static String COLUMN_ID = BaseColumns._ID;
        public static String COLUMN_NAME = "name";
        public static String COLUMN_QUANTITY = "quantity";
        public static String COLUMN_PRICE = "price";
        public static String COLUMN_IMAGE = "image";

        public static Uri CONTENT_URI = Uri.withAppendedPath(CONTENT_BASE_URI, TABLE_NAME);

    }
}
