package com.example.divyansh.inventoryapp.data;

import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.divyansh.inventoryapp.data.Contract.Entry;

/**
 * Created by Divyansh on 04/06/2017.
 */

public class DbHelper extends SQLiteOpenHelper {

    private static int DATABASE_VERSION = 1;
    private static String DATABASE_NAME = "inventory.db";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_TABLE = "CREATE TABLE " + Entry.TABLE_NAME + " ("
                + Entry.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Entry.COLUMN_NAME + " TEXT NOT NULL, "
                + Entry.COLUMN_QUANTITY + " INTEGER NOT NULL DEFAULT 0, "
                + Entry.COLUMN_PRICE + " INTEGER NOT NULL DEFAULT 0, "
                + Entry.COLUMN_IMAGE + " BLOB NOT NULL)";
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Entry.TABLE_NAME);
        onCreate(db);
    }
}
