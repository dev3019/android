package com.example.divyansh.inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.divyansh.inventoryapp.data.Contract.Entry;

/**
 * Created by Divyansh on 04/06/2017.
 */

public class InventoryCursorAdapter extends CursorAdapter {
    private static final String OUT_OF_STOCK = "Out of stock.";

    public InventoryCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }

    @Override
    public void bindView(View view, final Context context, Cursor cursor) {
        TextView nameTextView = (TextView) view.findViewById(R.id.list_item_name);
        TextView quantityTextView = (TextView) view.findViewById(R.id.list_item_quantity);
        TextView priceTextView = (TextView) view.findViewById(R.id.list_item_price);
        ImageView imageView = (ImageView) view.findViewById(R.id.list_item_image_view);
        Button button = (Button) view.findViewById(R.id.list_item_button);

        final long id = cursor.getLong(cursor.getColumnIndex(Entry.COLUMN_ID));
        String name = cursor.getString(cursor.getColumnIndex(Entry.COLUMN_NAME));
        final int mquantity = cursor.getInt(cursor.getColumnIndex(Entry.COLUMN_QUANTITY));
        float price = cursor.getFloat(cursor.getColumnIndex(Entry.COLUMN_PRICE));
        byte[] imageBlob = cursor.getBlob(cursor.getColumnIndex(Entry.COLUMN_IMAGE));
        price = Utilities.formatFloat(price);
        String quantity = String.valueOf(mquantity);
        if (mquantity <= 0) {
            button.setVisibility(View.GONE);
            quantity = OUT_OF_STOCK;
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(Utilities.decrementQuantity(context, mquantity, id) <= 0))
                    Toast.makeText(context, R.string.item_sold, Toast.LENGTH_SHORT).show();
            }
        });
        nameTextView.setText(name);
        quantityTextView.setText(quantity);
        priceTextView.setText("₹ ");
        priceTextView.append(String.valueOf(price));
        imageView.setImageBitmap(Utilities.processImage(imageBlob));
    }

}
