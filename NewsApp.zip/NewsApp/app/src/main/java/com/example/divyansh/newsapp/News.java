package com.example.divyansh.newsapp;

/**
 * Created by Divyansh on 19/05/2017.
 */

public class News {
    private String mTitle;
    private String mCategory;
    private String mUrl;

    public News(String mTitle, String mCategory, String mUrl) {
        this.mCategory = mCategory;
        this.mTitle = mTitle;
        this.mUrl = mUrl;
    }

    public String getmCategory() {
        return mCategory;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmUrl() {
        return mUrl;
    }
}
