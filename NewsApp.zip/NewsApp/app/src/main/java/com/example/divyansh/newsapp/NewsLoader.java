package com.example.divyansh.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

/**
 * Created by Divyansh on 19/05/2017.
 */

public class NewsLoader extends AsyncTaskLoader<List<News>> {
    String mURL;

    public NewsLoader(Context context, String url) {
        super(context);
        mURL = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<News> loadInBackground() {
        if (mURL == null) {
            return null;
        }
        List<News> data = QueryUtils.fetchNewsData(mURL);
        return data;
    }
}
