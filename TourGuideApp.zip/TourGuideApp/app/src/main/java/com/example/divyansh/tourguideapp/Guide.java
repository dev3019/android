package com.example.divyansh.tourguideapp;

/**
 * Created by Divyansh on 07/05/2017.
 */
public class Guide {
    //string for title
    private int mtitle;
    //integer for description
    private int mdescription;
    //integer for image resource id
    private int mImageResourceId = NO_IMAGE_RESOURCE;
    private static final int NO_IMAGE_RESOURCE = -1;

    //constructor
    public Guide(int title, int description, int imageResourceId) {
        mtitle = title;
        mdescription = description;
        mImageResourceId = imageResourceId;
    }

    //to check for image
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_RESOURCE;
    }

    //to get description id
    public int getDescription() {
        return mdescription;
    }

    //to get image resource id
    public int getImageResourceId() {
        return mImageResourceId;
    }

    //to get title
    public int getTitle() {
        return mtitle;
    }
}