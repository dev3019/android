package com.example.divyansh.tourguideapp;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class EntertainmentFragment extends android.support.v4.app.Fragment {


    public EntertainmentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        final ArrayList<Guide> arrayG = new ArrayList<Guide>();
        arrayG.add(new Guide(R.string.mbdMallT, R.string.mbdMall, R.drawable.mbdmall));
        arrayG.add(new Guide(R.string.flamezMallT, R.string.flamesMall, R.drawable.flamezmall));
        arrayG.add(new Guide(R.string.silverArcMallT, R.string.silverArcMall, R.drawable.silverarcmall));
        arrayG.add(new Guide(R.string.westendMallT, R.string.westendMall, R.drawable.westendmall));
        arrayG.add(new Guide(R.string.pavilionMallT, R.string.pavilionMall, R.drawable.pavilionmall));
        arrayG.add(new Guide(R.string.grandWalkMallT, R.string.granWalkMall, R.drawable.grandwalkmall));
        arrayG.add(new Guide(R.string.ansalPlazaT, R.string.ansalPlaza, R.drawable.ansalplaza));
        arrayG.add(new Guide(R.string.omaxePlazaT, R.string.omaxePlaza, R.drawable.omaxeplaza));
        GuideAdapter adapter = new GuideAdapter(getActivity(), arrayG);

        ListView listView = (ListView) rootView.findViewById(R.id.list1);
        listView.setAdapter(adapter);

        return rootView;
    }

}
