package com.example.divyansh.tourguideapp;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RestaurantsFragment extends android.support.v4.app.Fragment{


    public RestaurantsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        final ArrayList<Guide> arrayG = new ArrayList<Guide>();
        arrayG.add(new Guide(R.string.bistroFlammeBoisT, R.string.bistroFlammeBois, R.drawable.bistroflammebois));
        arrayG.add(new Guide(R.string.spiceCubeT, R.string.spiceCube, R.drawable.spicecube));
        arrayG.add(new Guide(R.string.yellowChilliT, R.string.yellowChilli, R.drawable.yellowchilli));
        arrayG.add(new Guide(R.string.colonelsCabinT, R.string.colonelsCabin, R.drawable.colonelscabin));
        arrayG.add(new Guide(R.string.indianSummerT, R.string.indianSummer, R.drawable.indiansummer));
        arrayG.add(new Guide(R.string.hawaiAddaT, R.string.hawaiAdda, R.drawable.hawaiadda));
        arrayG.add(new Guide(R.string.friendsDhabaT, R.string.friendsDhaba, R.drawable.friendsdhaba));
        arrayG.add(new Guide(R.string.rishiDhabaT, R.string.rishiDhaba, R.drawable.rishidhaba));
        arrayG.add(new Guide(R.string.panditJiDePrantheT, R.string.panditJiDePranthe, R.drawable.panditjidepranthe));
        GuideAdapter adapter = new GuideAdapter(getActivity(), arrayG);

        ListView listView = (ListView) rootView.findViewById(R.id.list1);
        listView.setAdapter(adapter);

        return rootView;
    }

}
