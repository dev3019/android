package com.example.divyansh.tourguideapp;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ActivitiesFragment extends android.support.v4.app.Fragment {


    public ActivitiesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        final ArrayList<Guide> arrayG = new ArrayList<Guide>();
        arrayG.add(new Guide(R.string.f2RacewayT, R.string.f2Raceway, R.drawable.f2raceway));
        arrayG.add(new Guide(R.string.smaaashT, R.string.smaaash, R.drawable.smaaash));
        arrayG.add(new Guide(R.string.bluoT, R.string.bluo, R.drawable.bluo));
        arrayG.add(new Guide(R.string.mysteryRoomsT, R.string.mysteryRooms, R.drawable.mysteryrooms));
        arrayG.add(new Guide(R.string.hardysWorldT, R.string.hardysWorld, R.drawable.hardysworld));
        arrayG.add(new Guide(R.string.tigerSafariT, R.string.tigerSafari, R.drawable.tigersafari));
        GuideAdapter adapter = new GuideAdapter(getActivity(), arrayG);

        ListView listView = (ListView) rootView.findViewById(R.id.list1);
        listView.setAdapter(adapter);

        return rootView;
    }

}
