package com.example.divyansh.tourguideapp;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HistoryFragment extends android.support.v4.app.Fragment {
    public HistoryFragment(){}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        View rootView = inflater.inflate(R.layout.list_view, container, false);
        final ArrayList<Guide> arrayG = new ArrayList<Guide>();
        arrayG.add(new Guide(R.string.phillaurFortT, R.string.phillaurFort, R.drawable.phillaurfort));
        arrayG.add(new Guide(R.string.payalFortT, R.string.payalFort, R.drawable.payalfort));
        arrayG.add(new Guide(R.string.rdbFortT, R.string.rdbFort, R.drawable.rdbfort));
        arrayG.add(new Guide(R.string.lodhiFortT, R.string.lodhiFort, R.drawable.lodhifort));
        GuideAdapter adapter = new GuideAdapter(getActivity(), arrayG);

        ListView listView = (ListView) rootView.findViewById(R.id.list1);
        listView.setAdapter(adapter);

        return rootView;
    }
}
