package com.example.divyansh.tourguideapp;


import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Divyansh on 07/05/2017.
 */
public class GuideAdapter extends ArrayAdapter<Guide> {
    public GuideAdapter(Activity context, ArrayList<Guide> arrayG) {
        super(context, 0, arrayG);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_view, parent, false);
        }
        Guide current_item = getItem(position);
        //for showing title
        TextView titleView = (TextView) listItemView.findViewById(R.id.title);
        titleView.setText(current_item.getTitle());
        //for showing description
        TextView descView = (TextView) listItemView.findViewById(R.id.descBox);
        descView.setText(current_item.getDescription());
        //for showing Image
        ImageView imageView = (ImageView) listItemView.findViewById(R.id.image);
        if (current_item.hasImage()) {
            imageView.setImageResource(current_item.getImageResourceId());
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }
        return listItemView;
    }
}