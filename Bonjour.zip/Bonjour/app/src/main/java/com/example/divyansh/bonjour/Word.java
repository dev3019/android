package com.example.divyansh.bonjour;

/**
 * Created by Divyansh on 01/05/2017.
 */
public class Word {
    //String for default words
    private String mDefaultTranslation;
    //String for french words
    private String mFrenchTranslation;
    //integer for image resource id
    private int mImageResoucreId = NO_IMAGE_RESOURCE;
    private static final int NO_IMAGE_RESOURCE = -1;
    //integer for audio files
    private int mAudioFile;

    public Word(String mDefaultTranslation, String mFrenchTranslation, int mImageResoucreId, int mAudioFile) {
        this.mDefaultTranslation = mDefaultTranslation;
        this.mFrenchTranslation = mFrenchTranslation;
        this.mImageResoucreId = mImageResoucreId;
        this.mAudioFile = mAudioFile;
    }

    public Word(String mDefaultTranslation, String mFrenchTranslation, int mAudioFile) {
        this.mDefaultTranslation = mDefaultTranslation;
        this.mFrenchTranslation = mFrenchTranslation;
        this.mAudioFile = mAudioFile;
    }

    //to check for image
    public boolean hasImage() {
        return mImageResoucreId != NO_IMAGE_RESOURCE;
    }

    public String getmDefaultTranslation() {
        return mDefaultTranslation;
    }

    public String getmFrenchTranslation() {
        return mFrenchTranslation;
    }

    public int getmImageResoucreId() {
        return mImageResoucreId;
    }

    public int getmAudioFile() {
        return mAudioFile;
    }
}
