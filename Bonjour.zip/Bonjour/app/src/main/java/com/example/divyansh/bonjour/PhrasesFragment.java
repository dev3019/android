package com.example.divyansh.bonjour;


import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class PhrasesFragment extends Fragment {

    private MediaPlayer mp;
    AudioManager mAudioManager;
    AudioManager.OnAudioFocusChangeListener afChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                        // Permanent loss of audio focus so release all the resources
                        releaseMediaPlayer();
                    } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                            focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                        // Pause playback
                        mp.pause();
                        mp.seekTo(0);
                    } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
                        // Your app has been granted audio focus again
                        // Raise volume to normal, restart playback if necessary
                        mp.start();
                    }
                }
            };
    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };

    public PhrasesFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.list_view, container, false);
        mAudioManager= (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);
        //initializing numbers array
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("Where are you going?", "où allez-vous?",
                R.raw.phrases_where_are_you_going));
        words.add(new Word("What is your name?", "Comment vous appelez-vous?",
                R.raw.phrases_what_is_your_name));
        words.add(new Word("My name is...", "Mon nom est...", R.raw.phrases_my_name_is));
        words.add(new Word("How are you feeling?", "Comment allez-vous?",
                R.raw.phrases_how_are_you_feeling));
        words.add(new Word("I’m feeling good.", "Je me sens bien.", R.raw.phrases_im_feeling_good));
        words.add(new Word("Are you coming?", "Viens-tu?", R.raw.phrases_are_you_coming));
        words.add(new Word("Yes, I’m coming.", "Oui j'arrive.", R.raw.phrases_yes_im_coming));
        words.add(new Word("I’m coming.", "J'arrive.", R.raw.phrases_im_coming));
        words.add(new Word("Let’s go.", "Allons-y.", R.raw.phrases_lets_go));
        words.add(new Word("Come here.", "Venez ici.", R.raw.phrases_come_here));

        WordAdapter adapter = new WordAdapter(getActivity(), words, R.color.category_phrases);

        ListView listView = (ListView) rootview.findViewById(R.id.list);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //request audiofocus for playback
                int result = mAudioManager.requestAudioFocus(afChangeListener,
                        AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
                releaseMediaPlayer();
                if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    mp = MediaPlayer.create(getActivity(), words.get(position).getmAudioFile());
                    mp.start();
                    //Listener to release the resources from the memory when the sound stops
                    mp.setOnCompletionListener(mCompletionListener);
                }
            }
        });
        return rootview;
    }
    @Override
    public void onStop() {
        super.onStop();
        //release the resources when activity stops.
        releaseMediaPlayer();
    }

    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mp != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mp.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mp = null;
            //to release audiofocus
            mAudioManager.abandonAudioFocus(afChangeListener);
        }
    }
}