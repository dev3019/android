package com.example.divyansh.bonjour;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Divyansh on 01/05/2017.
 */
public class WordAdapter extends ArrayAdapter<Word>{

    //resource id for color
    private int mColorResourceId;

    public WordAdapter(Activity context, ArrayList<Word> words, int colorResourceId) {
        super(context, 0, words);
        mColorResourceId = colorResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.word_design, parent, false);
        }
        Word local_word = getItem(position);
        //for showing image
        ImageView frenchImageView = (ImageView) listItemView.findViewById(R.id.french_image_view);
        if (local_word.hasImage()) {
            frenchImageView.setImageResource(local_word.getmImageResoucreId());
            frenchImageView.setVisibility(View.VISIBLE);
        } else {
            frenchImageView.setVisibility(View.GONE);
        }
        //for showing french words
        TextView frenchTextView = (TextView) listItemView.findViewById(R.id.french_text_view);
        frenchTextView.setText(local_word.getmFrenchTranslation());
        //for showing default words
        TextView defaultTextView = (TextView) listItemView.findViewById(R.id.default_text_view);
        defaultTextView.setText(local_word.getmDefaultTranslation());

        //set theme color for list item
        View textbox = listItemView.findViewById(R.id.text_box);
        //find the color that the resource id maps to
        int color = ContextCompat.getColor(getContext(), mColorResourceId);
        //Set the background color
        textbox.setBackgroundColor(color);

        return listItemView;
    }
}
