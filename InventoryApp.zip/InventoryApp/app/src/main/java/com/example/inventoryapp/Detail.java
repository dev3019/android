package com.example.inventoryapp;

import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.inventoryapp.data.InventoryContract.InventoryEntry;

/**
 * Created by Divyansh on 14/06/2017.
 */

public class Detail extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{

    private Uri uri;
    private ImageView imageView;
    private String message;
    private TextView nameTextView;
    private TextView quantityTextView;
    private TextView priceTextView;
    int quantity;
    private static final int LOADER=1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        setTitle(R.string.details);

        uri=getIntent().getData();
        if (uri==null){
            finish();
            return;
        }
        nameTextView=(TextView)findViewById(R.id.name_detail);
        quantityTextView=(TextView)findViewById(R.id.quantity_detail);
        priceTextView=(TextView)findViewById(R.id.price_detail);
        imageView=(ImageView)findViewById(R.id.image_detail);

        Button recieveButton=(Button)findViewById(R.id.item_recieve_button);
        recieveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.incrementQuantity(getApplicationContext(),quantity, ContentUris.parseId(uri));
            }
        });
        Button soldButton=(Button)findViewById(R.id.item_sold_button);
        soldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.decrementQuantity(getApplicationContext(),quantity,ContentUris.parseId(uri));
            }
        });
        getLoaderManager().initLoader(LOADER,null,this);
        Button orderButton=(Button)findViewById(R.id.order_button);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT,message);
                if (intent.resolveActivity(getPackageManager())!=null)
                    startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_delete:
                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                builder.setTitle(R.string.delete_message);
                builder.setNegativeButton(getString(R.string.delete_yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        long rowsAffected=getContentResolver().delete(uri,null,null);
                        if (!(rowsAffected<=0)){
                            finish();
                        }
                    }
                });
                builder.setPositiveButton(R.string.delete_no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (dialog!=null){
                            dialog.dismiss();
                        }
                    }
                });
                builder.create().show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new CursorLoader(this,
                uri,
                null,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data.moveToFirst()){
            String name=data.getString(data.getColumnIndex(InventoryEntry.COLUMN_NAME));
            nameTextView.setText(name);
            quantity=data.getInt(data.getColumnIndex(InventoryEntry.COLUMN_QUANTITY));
            message="I need "+quantity+" more of "+name;
            quantityTextView.setText(String.valueOf(quantity));
            priceTextView.setText("₹ ");
            priceTextView.append(data.getString(data.getColumnIndex(InventoryEntry.COLUMN_PRICE)));
            imageView.setImageBitmap(Utils.processImage(data.getBlob(data.getColumnIndex(InventoryEntry.COLUMN_IMAGE))));
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        nameTextView.setText("");
        priceTextView.setText("");
        quantityTextView.setText("");
        quantity=0;
    }
}
