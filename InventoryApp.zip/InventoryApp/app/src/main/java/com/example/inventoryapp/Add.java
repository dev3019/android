package com.example.inventoryapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

import com.example.inventoryapp.data.InventoryContract.InventoryEntry;

/**
 * Created by Divyansh on 14/06/2017.
 */

public class Add extends AppCompatActivity {

    static final int REQUEST_CAMERA=1;
    byte[]imageBlob=null;
    private ImageView imageView;
    private EditText nameTextView;
    private EditText quantityTextView;
    private EditText priceTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);

        Button imageButton=(Button)findViewById(R.id.image_button_add);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (intent.resolveActivity(getPackageManager())!=null)
                    startActivityForResult(intent,REQUEST_CAMERA);
            }
        });
        nameTextView=(EditText)findViewById(R.id.item_name_add);
        quantityTextView=(EditText)findViewById(R.id.item_quantity_add);
        priceTextView=(EditText)findViewById(R.id.item_price_add);
        imageView=(ImageView)findViewById(R.id.item_image_add);

        Button saveButton=(Button)findViewById(R.id.data_button_add);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
    }

    private void insertData() {
        String name=nameTextView.getText().toString().trim();
        String mQuantity=quantityTextView.getText().toString().trim();
        String mPrice=priceTextView.getText().toString().trim();
        int quantity=-1;
        if (!mQuantity.isEmpty()){
            quantity=Integer.parseInt(mQuantity);
        }
        float price=-1;
        if (!mPrice.isEmpty()){
            price=Float.parseFloat(mPrice);
            price=Utils.formatFloat(price);
        }

        ContentValues values=new ContentValues();
        values.put(InventoryEntry.COLUMN_NAME,name);
        values.put(InventoryEntry.COLUMN_QUANTITY,quantity);
        values.put(InventoryEntry.COLUMN_PRICE,price);
        values.put(InventoryEntry.COLUMN_IMAGE,imageBlob);

        Uri uri=getContentResolver().insert(InventoryEntry.CONTENT_URI,values);
        String ab=uri.toString();
        Log.e("MainActivity",ab);

        if (ContentUris.parseId(uri)!=-1){
            Toast.makeText(getApplicationContext(),R.string.data_saved,Toast.LENGTH_SHORT).show();
            NavUtils.navigateUpFromSameTask(this);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode==REQUEST_CAMERA){
            if (resultCode==RESULT_OK){
                Bitmap image=(Bitmap)data.getExtras().get("data");
                imageView.setImageBitmap(image);

                ByteArrayOutputStream stream= new ByteArrayOutputStream();
                image.compress(Bitmap.CompressFormat.PNG,100,stream);
                imageBlob=stream.toByteArray();
            }
        }
    }
}
