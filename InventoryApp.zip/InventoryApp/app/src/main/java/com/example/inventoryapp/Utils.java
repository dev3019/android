package com.example.inventoryapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.ByteArrayInputStream;
import java.text.DecimalFormat;
import com.example.inventoryapp.data.InventoryContract.InventoryEntry;

/**
 * Created by Divyansh on 14/06/2017.
 */

public final class Utils {

    private Utils() {
    }

    public static float formatFloat(float price) {
        DecimalFormat format = new DecimalFormat("#.#");
        price = Float.valueOf(format.format(price));
        return price;
    }

    public static long decrementQuantity(Context context, int mquantity, long id) {
        Uri uri = ContentUris.withAppendedId(InventoryEntry.CONTENT_URI, id);
        int quantity = mquantity - 1;
        if (quantity < 0) {
            return -1;
        }
        ContentValues values = new ContentValues();
        values.put(InventoryEntry.COLUMN_QUANTITY, quantity);
        return context.getContentResolver().update(uri, values, null, null);
    }

    public static long incrementQuantity(Context context, int mquantity, long id) {
        Uri uri = ContentUris.withAppendedId(InventoryEntry.CONTENT_URI, id);
        int quantity = mquantity + 1;
        if (quantity < 0) {
            return -1;
        }
        ContentValues values = new ContentValues();
        values.put(InventoryEntry.COLUMN_QUANTITY, quantity);
        return context.getContentResolver().update(uri, values, null, null);
    }

    public static Bitmap processImage(byte[] image) {
        ByteArrayInputStream stream = new ByteArrayInputStream(image);
        return BitmapFactory.decodeStream(stream);
    }
}
