package com.example.inventoryapp.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.example.inventoryapp.data.InventoryContract.InventoryEntry;

/**
 * Created by Divyansh on 14/06/2017.
 */

public class InventoryProvider extends ContentProvider {
    private InventoryDbHelper dbHelper;
    private static UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    private static final int PRODUCTS = 100;
    private static final int PRODUCTS_ID = 101;

    static {
        uriMatcher.addURI(InventoryContract.CONTENT_AUTHORITY, InventoryEntry.TABLE_NAME, PRODUCTS);
        uriMatcher.addURI(InventoryContract.CONTENT_AUTHORITY, InventoryEntry.TABLE_NAME + "/#", PRODUCTS_ID);
    }

    @Override
    public boolean onCreate() {
        dbHelper = new InventoryDbHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        int match = uriMatcher.match(uri);
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        Cursor cursor;
        switch (match) {
            case PRODUCTS:
                cursor = database.query(InventoryEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                break;
            case PRODUCTS_ID:
                selection = InventoryEntry.COLUMN_ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                cursor = database.query(InventoryEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Cannot query unknown uri :" + uri);
        }
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        int match = uriMatcher.match(uri);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        long id;
        switch (match) {
            case PRODUCTS:
                try {
                    validate(values);
                    id = database.insert(InventoryEntry.TABLE_NAME, null, values);
                } catch (Exception e) {
                    id = -1;
                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                throw new IllegalArgumentException("Insert is not supported for :" + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return ContentUris.withAppendedId(uri, id);
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        int match = uriMatcher.match(uri);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        switch (match) {
            case PRODUCTS_ID:
                selection = InventoryEntry.COLUMN_ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                getContext().getContentResolver().notifyChange(uri, null);
                return database.update(InventoryEntry.TABLE_NAME, values, selection, selectionArgs);
            default:
                throw new IllegalArgumentException("Update is not supported for :" + uri);
        }
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        int match = uriMatcher.match(uri);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        switch (match) {
            case PRODUCTS_ID:
                selection = InventoryEntry.COLUMN_ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                getContext().getContentResolver().notifyChange(uri, null);
                return database.delete(InventoryEntry.TABLE_NAME, selection, selectionArgs);
            default:
                throw new IllegalArgumentException("Delete is not supported for :" + uri);
        }
    }

    private void validate(ContentValues values) throws Exception {
        String name = values.getAsString(InventoryEntry.COLUMN_NAME);
        int quantity = values.getAsInteger(InventoryEntry.COLUMN_QUANTITY);
        float price = values.getAsFloat(InventoryEntry.COLUMN_PRICE);
        byte[] image = values.getAsByteArray(InventoryEntry.COLUMN_IMAGE);
        if (name.isEmpty()) {
            throw new IllegalArgumentException("Please enter a product name.");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Enter valid a quantity.");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("Enter valid a price.");
        }
        if (image == null) {
            throw new IllegalArgumentException("Please take the product image.");
        }
    }
}
