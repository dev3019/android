package com.example.divyansh.booklisting;

/**
 * Created by Divyansh on 17/05/2017.
 */

public class Books {
    private String mTitle;
    private String mPublisher;
    private String mAuthor;
    private String mUrl;

    public Books(String mTitle, String mPublisher, String mAuthor, String url) {
        this.mTitle = mTitle;
        this.mPublisher = mPublisher;
        this.mAuthor = mAuthor;
        this.mUrl = url;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmPublisher() {
        return mPublisher;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public String getmUrl() {
        return mUrl;
    }
}
