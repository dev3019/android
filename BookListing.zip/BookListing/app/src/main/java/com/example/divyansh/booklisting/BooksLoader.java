package com.example.divyansh.booklisting;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

/**
 * Created by Divyansh on 17/05/2017.
 */

public class BooksLoader extends AsyncTaskLoader<List<Books>> {
    String mURL;

    public BooksLoader(Context context, String url) {
        super(context);
        mURL = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Books> loadInBackground() {
        if (mURL == null) {
            return null;
        }
        List<Books> data = QueryUtils.fetchBooksData(mURL);
        return data;
    }
}
