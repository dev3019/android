package com.example.divyansh.booklisting;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.app.LoaderManager.LoaderCallbacks;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderCallbacks<List<Books>> {

    private SimpleArrayAdapter mAdapter;
    private static final int BOOKLIST_LOADER_ID = 1;

    public static final String LOG_TAG = MainActivity.class.getName();
    private static String GOOGLE_BOOOKS_REQUEST_URL;
    private TextView mEmptyStateTextView;

    @Override
    public Loader<List<Books>> onCreateLoader(int id, Bundle args) {
        return new BooksLoader(this, GOOGLE_BOOOKS_REQUEST_URL);
    }

    @Override
    public void onLoaderReset(Loader<List<Books>> loader) {
        mAdapter.clear();
    }

    @Override
    public void onLoadFinished(Loader<List<Books>> loader, List<Books> data) {
        mAdapter.clear();
        View mProgressBar = findViewById(R.id.progressBar);
        mProgressBar.setVisibility(View.GONE);
        mEmptyStateTextView.setText(R.string.empty_state);
        if (data != null && !data.isEmpty()) {
            mAdapter.addAll(data);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);

        //new adapter that takes empty list of books asinput
        mAdapter = new SimpleArrayAdapter(this, new ArrayList<Books>());

        //reference to the listview in the layout
        ListView bookListView = (ListView) findViewById(R.id.listView);
        //set the adapter on listview so list can be displayed to user
        bookListView.setAdapter(mAdapter);

        mEmptyStateTextView = (TextView) findViewById(R.id.emptyView);
        bookListView.setEmptyView(mEmptyStateTextView);
        //to check connectivity to internet
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(BOOKLIST_LOADER_ID, null, this);
        } else {
            View mProgressBar = findViewById(R.id.progressBar);
            mProgressBar.setVisibility(View.GONE);
            mEmptyStateTextView.setText(R.string.no_connection);
        }
        //onClickLisnter to open the search for book in browser
        bookListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Find the current book that was clicked on
                Books currentBook = mAdapter.getItem(position);

                // Convert the String URL into a URI object (to pass into the Intent constructor)
                Uri bookUri = Uri.parse(currentBook.getmUrl());

                // Create a new intent to view the book URI
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, bookUri);

                // Send the intent to launch a new activity
                startActivity(websiteIntent);
            }
        });

        //Search Button with onClickListener to search the book
        Button goButton = (Button) findViewById(R.id.searchButton);
        goButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAdapter.clear();
                ConnectivityManager cm =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnected()) {
                    View mProgressBar = findViewById(R.id.progressBar);
                    mProgressBar.setVisibility(View.VISIBLE);
                    mEmptyStateTextView.setVisibility(View.GONE);
                    EditText searchBar = (EditText) findViewById(R.id.searchBar);
                    String bookName = searchBar.getText().toString().toLowerCase();
                    GOOGLE_BOOOKS_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?q="+bookName.replaceAll(" ","%20")+ "&maxResults=10";
                    getLoaderManager().restartLoader(BOOKLIST_LOADER_ID, null, MainActivity.this);
                } else {
                    View mProgressBar = findViewById(R.id.progressBar);
                    mProgressBar.setVisibility(View.GONE);
                    mEmptyStateTextView.setText(R.string.connect_pls);
                }
            }
        });
    }
}