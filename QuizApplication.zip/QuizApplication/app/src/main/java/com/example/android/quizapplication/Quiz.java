package com.example.android.quizapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Quiz extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
    }

    int score = 0;

    public void submit(View view) {
        CheckBox NewDelhiCheckBox = (CheckBox) findViewById(R.id.chckbox1_1);
        CheckBox AgraCheckBox = (CheckBox) findViewById(R.id.chckbox1_2);
        CheckBox MumbaiCheckBox = (CheckBox) findViewById(R.id.chckbox1_3);
        if (AgraCheckBox.isChecked() || MumbaiCheckBox.isChecked()) {
            score += 0;
        } else if (NewDelhiCheckBox.isChecked())
            score++;
        CheckBox ManmohanSinghCheckBox = (CheckBox) findViewById(R.id.chckbox2_1);
        CheckBox NarendraModiCheckBox = (CheckBox) findViewById(R.id.chckbox2_2);
        CheckBox PratibhaPatilCheckBox = (CheckBox) findViewById(R.id.chckbox2_3);
        if (ManmohanSinghCheckBox.isChecked() || PratibhaPatilCheckBox.isChecked()) {
            score += 0;
        } else if (NarendraModiCheckBox.isChecked())
            score++;
        CheckBox RedFortCheckBox = (CheckBox) findViewById(R.id.chckbox3_1);
        CheckBox TajMahalCheckBox = (CheckBox) findViewById(R.id.chckbox3_2);
        CheckBox JantarMantarCheckBox = (CheckBox) findViewById(R.id.chckbox3_3);
        if (RedFortCheckBox.isChecked() || JantarMantarCheckBox.isChecked()) {
            score += 0;
        } else if (TajMahalCheckBox.isChecked())
            score++;
        CheckBox RahulGandhiCheckBox = (CheckBox) findViewById(R.id.chckbox4_1);
        CheckBox JawharlalNehruCheckBox = (CheckBox) findViewById(R.id.chckbox4_2);
        CheckBox MahatmaGandhiCheckBox = (CheckBox) findViewById(R.id.chckbox4_3);
        if (RahulGandhiCheckBox.isChecked() || JawharlalNehruCheckBox.isChecked()) {
            score += 0;
        } else if (MahatmaGandhiCheckBox.isChecked())
            score++;
        CheckBox tweleveCheckBox = (CheckBox) findViewById(R.id.chckbox5_1);
        CheckBox twentythreeCheckBox = (CheckBox) findViewById(R.id.chckbox5_2);
        CheckBox twentyfourCheckBox = (CheckBox) findViewById(R.id.chckbox5_3);
        if (tweleveCheckBox.isChecked() || twentythreeCheckBox.isChecked()) {
            score += 0;
        } else if (twentyfourCheckBox.isChecked())
            score++;
        EditText nameField = (EditText) findViewById(R.id.name_field);
        String Value = nameField.getText().toString();
        Toast.makeText(this, Value + "your score is" + score, Toast.LENGTH_SHORT).show();
        score = 0;


    }
}



